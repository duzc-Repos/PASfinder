wget ftp://ftp.ncbi.nih.gov/genomes/Homo_sapiens/ARCHIVE/BUILD.37.3/CHR_X/hs_ref_GRCh37.p5_chrX.fa.gz -O chrX.fa.gz
gzip chrX.fa
samtools faidx chrX.fa
bowtie-build ./chrX.fa chrX.fa

