################################################
# 1. preprocessing
# Basic usage: python3 <path to>/1.processing_artificial_sequence.py -s <library type> -i <input file(s), one or more> -a <adaptor sequence> -o <path to output, folder>
# More parameter details: python3 <path to>/1.processing_artificial_sequence.py -h
################################################
# 1.1 sense library 
python3 ../bin/1.processing_artificial_sequence.py -i ./0.rawdata/testchrX_3seq_5.fq.gz -s 5 -a gatcggaagagc -o ./1.preprocessing
python3 ../bin/1.processing_artificial_sequence.py -i ./0.rawdata/testchrX_PAC-seq_5.fq.gz -a nnnnagatcggaagagc -l 6 -s 5 -o ./1.preprocessing
# 1.2 anti-sense library
python3 ../bin/1.processing_artificial_sequence.py -i ./0.rawdata/*3.fq.gz -a agatcggaagagc -s 3 -o ./1.preprocessing

################################################
# 2. mapping
# Usage: python3 <path to>/2.bowtie_SE_mapping.py -p <#CPU> -in <path to bowtie index> -i <input file(s), one or more> -o <path to output, folder>
################################################
python3 ../bin/2.bowtie_SE_mapping.py -p 10 -in ./bowtie_index_chrX/chrX.fa -i ./1.preprocessing/*.fq.gz -o ./2.mapping

################################################
# 3. collapasing reads with same ends
# Usage:
#   For sene library: python3 <path to>/3.collapasing.py -s 5 -l <polyA_length> -gs <*.chrom.sizes> -i <input file(s), one or more> -o <path to output, folder> 
#   For anti-sense library: python3 <path to>/3.collapasing.py -s 3  -gs <*.chrom.sizes> -i <input file(s), one or more> -o <path to output, folder>
################################################
# 1.1 sense library
python3 ../bin/3.collapasing.py -i ./2.mapping/*5.sort.bam -s 5 -l 8 -o ./3.filter_internal_primed_events -gs ../database/hg19.chrom.sizes
# 1.2 anti-sense library
python3 ../bin/3.collapasing.py -i ./2.mapping/*3.sort.bam -s 3 -o ./3.filter_internal_primed_events -gs ../database/hg19.chrom.sizes

################################################
# 4. filter_internal_primed_events
# Usage: python3 <path to>/4.filter_internal_primed_events.py -i <input file(s), one or more> -o <path to output, folder> -g < path to genome .fasta>
# More parameter details: python3 <path to>/4.filter_internal_primed_events.py -h
################################################
python3 ../bin/4.filter_internal_primed_events.py  -i ./3.filter_internal_primed_events/*.pCS.bed -g ./bowtie_index_chrX/chrX.fa -o ./3.filter_internal_primed_events/ -m heuristic

################################################
# 5. identify reliable cleavage sites
# Usage: python3 <path to>/5.identifying_reliable_cleavage_sites.py -j <#CPU> -e <extend #bp downstream of transcript end> -r <annotation file processed by "annotation_preparation.py"> -p <P-value> -i <input file(s), one or more> -o <path to output, folder>
# More parameter details: python3 <path to>/5.identifying_reliable_cleavage_sites.py -h
################################################
python3 ../bin/5.identifying_reliable_cleavage_sites.py -j 20 -e 1000 -r ../database/gencode.v19.annotation.bed -i ./3.filter_internal_primed_events/*.heuristic.bed -o ./4.reliable_cleavage_sites -p 0.05

################################################
# 5. clustering
# Usage: python3 <path to>/6.clustering_cleavage_sites.py -i <input file(s), one or more> -o <path to output, folder> -p <P-value> -d <distance for clustering>
################################################
python3 ../bin/6.clustering_cleavage_sites.py -i ./4.reliable_cleavage_sites/*.rCS.bed -o ./5.cluster -p 0.05 -d 7



